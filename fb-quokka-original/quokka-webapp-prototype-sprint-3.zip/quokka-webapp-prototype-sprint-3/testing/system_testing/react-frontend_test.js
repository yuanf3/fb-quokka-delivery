Feature('Quokka-migration-APP-testing');

/*
    The aim of this collection is to simulate a normal user using our migration App to migrate the posts and an admin approves/rejects the migration requests made by the normal user.

    <------------------------------------------------------------------------------------------------------------------------------------------>
    Two user invoved in this testing
    - Bob: 
        Represents a public user who does not have admin privilege and try to perform various action when using the Quokka migration APP
    - Admin
        Simulates the admin user who main purpose in this testing is to accept or reject the migration request made from Bob
    
    <------------------------------------------------------------------------------------------------------------------------------------------>
    One test Facebook account involved in this testing
    - Bob:
        Bob's Facebook account have been used to access Bob's Facebook posts

    <------------------------------------------------------------------------------------------------------------------------------------------>
    Test data Facebook post:

    - 2658160797819865_2703353756633902: "It always seems impossible until it's done"
        For testing the generate migration functionalities

    - 2658160797819865_2703347956634482: "What book(s) make you cry?" with one image
        For testing the image migration functionality

    - 2658160797819865_2688092564826688: "Another post for system testing"
    - 2658160797819865_2687484038220874: "Hi a post for system testing"
        For testing migrate all posts funtionality
*/

// User Quokka network account
const BOB_USERNAME = "Bob"
const BOB_PASS = "Bob"

const ADMIN_USERNAME = "admin"
const ADMIN_PASS = "admin"

// Facebook account
const BOB_FB_EMAIL = "EMAIL"
const BOB_FB_PASS = "PASS"

// Test data Facebook post:
const TARGET_POST_ID = "2658160797819865_2703353756633902"
const TARGET_POST_ID1 = "2658160797819865_2703347956634482"
const TARGET_POST_ID2 = "2658160797819865_2688092564826688"
const TARGET_POST_ID3 = "2658160797819865_2687484038220874"

//Default waiting time
const DEFAULT_WAITING = 2
const DEFAULT_LONG_WAITING = 4


//Bob access migration page
Scenario('Verify Migration Page is Accessible', ({ I }) => {
    I.amOnPage('/');
    I.fillField('Email Address', BOB_USERNAME);
    I.fillField('Password', BOB_PASS);
    I.click('Log In');
    I.see('Welcome to Quokka Network!');
});

//Bob login with his Facebook account on migration page
Scenario('Verify Facebook Login Functionality', ({ I }) => {
    I.amOnPage('data-migration/');
    I.see('LOGIN WITH FACEBOOK');
    I.click('Login with Facebook');
    I.switchToNextTab();
    I.see('Log in to use your Facebook account');
    I.see('Email address or phone number:');

    I.fillField('email', BOB_FB_EMAIL);
    I.fillField('pass', secret(BOB_FB_PASS));

    I.click('Log In');
    I.switchToNextTab();
    I.see('Bob Dillon');
});

//Bob perform search action on migration apge
Scenario('Verify Search Functionality', ({ I }) => {
    I.amOnPage('data-migration/#posts');
    I.see('Search');
    I.fillField( locate('input').withAttr({ placeholder: 'Search', class:"form-control" }), 'What book(s) make you cry?');
    I.see('What book(s) make you cry?');
    I.dontSee('It always seems impossible until it\'s done');
    I.fillField( locate('input').withAttr({ placeholder: 'Search', class:"form-control" }), 'It always seems impossible until it\'s done');
    I.dontSee('What book(s) make you cry?');
});

//Bob click Lest recent button
Scenario('Verify Least Recent Functionality', async ({ I }) => {

    I.amOnPage('data-migration/#requests');
    I.amOnPage('data-migration/#posts');
    I.wait(DEFAULT_LONG_WAITING);
    I.scrollPageToBottom();
    I.wait(DEFAULT_LONG_WAITING);
    I.scrollPageToBottom();
    I.wait(DEFAULT_LONG_WAITING);
    I.see('All posts loaded');

    I.click('Least recent');

    //check the first post in the list
    var value = await I.grabTextFrom( { xpath: '/html/body/div[2]/div/div/div/div/main/article/div/div/div/div/div[1]/div[1]/p' });
    I.assert(value=="Hi a post for system testing", true);

    //check the second post in the list
    var value = await I.grabTextFrom( { xpath: '/html/body/div[2]/div/div/div/div/main/article/div/div/div/div/div[2]/div[1]/p' });
    I.assert(value=="Another post for system testing", true);
});

//To test the most interactions button is Accessible
Scenario('Verify Most Interactions Functionality', async ({ I }) => {

    I.click('Most interactions');

    //check the first post in the list
    var value = await I.grabTextFrom( { xpath: '/html/body/div[2]/div/div/div/div/main/article/div/div/div/div/div[1]/div[1]/p' });
    I.assert(value=="What book(s) make you cry?", true);

    //check the second post in the list
    var value = await I.grabTextFrom( { xpath: '/html/body/div[2]/div/div/div/div/main/article/div/div/div/div/div[2]/div[1]/p' });
    I.assert(value=="It always seems impossible until it's done", true);
});

//Bob migrate a post to Quokka network
Scenario('Verify Facebook Post Migrate Functionality', ({ I }) => {
    I.amOnPage('data-migration/#posts');
    I.see('It always seems impossible until it\'s done');
    I.click('#rm_' + TARGET_POST_ID);
    I.click('OK');

});

Scenario('Verify Hide Requested Functionality', ({ I }) => {
    I.click(locate('a').withAttr({ href: '#', class:"navbar-brand" }));
    I.click(locate('a').withAttr({ href: '#posts', class:"nav-link" }));
    I.click('Most recent');
    I.see('It always seems impossible until it\'s done');
    I.click('#group-search-checkbox');
    I.dontSee('It always seems impossible until it\'s done');
});

Scenario('Verify Admin Approval Functionality (Reject)', ({ I }) => {

    session('Admin user', () => {
        I.amOnPage('/');
        I.fillField('Email Address', ADMIN_USERNAME);
        I.fillField('Password', ADMIN_PASS);
        I.click('Log In');
        I.amOnPage('data-migration');
        I.amOnPage('data-migration/#requests');
        I.see('It always seems impossible until it\'s done');
        I.fillField( locate('textarea').withAttr({ placeholder: 'Provide reason for rejection (optional)', class:"form-control", id:"formReason" }), 'Not enough content');
        I.click('#decline_' + TARGET_POST_ID);
        I.click('OK');
      });

    I.click(locate('a').withAttr({ href: '#', class:"navbar-brand" }));
    I.click(locate('a').withAttr({ href: '#posts', class:"nav-link" }));
    I.wait(DEFAULT_WAITING);
    I.see('It always seems impossible until it\'s done');
    I.see('Migration rejected');
    I.see('Not enough content');
});

Scenario('Verify User Rerequest Functionality', ({ I }) => {

    I.amOnPage('data-migration/#posts');
    I.see('It always seems impossible until it\'s done');
    I.click('#rm_' + TARGET_POST_ID);
    I.click('OK');
    I.wait(DEFAULT_WAITING);
    I.see('Waiting for approval');

    session('Admin user', () => {
        I.amOnPage('/');
        I.fillField('Email Address', 'admin');
        I.fillField('Password', 'admin');
        I.click('Log In');
        I.amOnPage('data-migration');
        I.amOnPage('data-migration/#requests');
        I.see('It always seems impossible until it\'s done');
      });
});

Scenario('Clean up Testing Data', async ({ I }) => {

    userData = {
        username: ADMIN_USERNAME,
        password: ADMIN_PASS
    }

    var res = await I.sendPostRequest('wp-json/jwt-auth/v1/token', userData);

    const authToken = res.data.data.token;

    header = {
        Authorization: "Bearer " + authToken
    }

    var res = await I.sendGetRequest('wp-json/custom-api/v1/fbposts/' + TARGET_POST_ID, header);
    var postID = res.data.ID;
    I.sendDeleteRequest('wp-json/wp/v2/fbposts/' + postID, header);

    var res = await I.sendGetRequest('wp-json/custom-api/v1/fbposts/' + TARGET_POST_ID, header);
    var postID = res.data.ID;
    I.sendDeleteRequest('wp-json/wp/v2/fbposts/' + postID, header);
    
});

Scenario('Verify Admin Approval Functionality (Approve)', ({ I }) => {
    I.amOnPage('data-migration/#posts');
    I.amOnPage('data-migration/#requests');
    I.amOnPage('data-migration/#posts');
    I.see('It always seems impossible until it\'s done');
    I.click('#rm_' + TARGET_POST_ID);
    I.click('OK');
    I.wait(DEFAULT_WAITING);
    I.see('Waiting for approval');

    session('Admin user', () => {
        I.amOnPage('/');
        I.fillField('Email Address', ADMIN_USERNAME);
        I.fillField('Password', ADMIN_PASS);
        I.click('Log In');
        I.amOnPage('data-migration');
        I.amOnPage('data-migration/#requests');
        I.see('It always seems impossible until it\'s done');
        I.selectOption('Choose a community', 'Welcome Room (public)');
        I.click('#migrate_' + TARGET_POST_ID);
        I.click('OK');
      });

    I.click(locate('a').withAttr({ href: '#', class:"navbar-brand" }));
    I.click(locate('a').withAttr({ href: '#posts', class:"nav-link" }));
    I.wait(DEFAULT_WAITING);
    I.see('It always seems impossible until it\'s done');
    I.see('Post migrated');

});

Scenario('Verify Image Migrate Functionality (Approve)', ({ I }) => {
    I.amOnPage('data-migration/#posts');
    I.amOnPage('data-migration/#requests');
    I.amOnPage('data-migration/#posts');
    I.see('What book(s) make you cry?');
    I.click('#rm_' + TARGET_POST_ID1);
    I.click('OK');


    session('Admin user', () => {
        I.amOnPage('/');
        I.fillField('Email Address', ADMIN_USERNAME);
        I.fillField('Password', ADMIN_PASS);
        I.click('Log In');
        I.amOnPage('data-migration');
        I.amOnPage('data-migration/#requests');
        I.see('What book(s) make you cry?');
        I.selectOption('Choose a community', 'Welcome Room (public)');
        I.click('#migrate_' + TARGET_POST_ID1);
        I.click('OK');
      });

    I.click(locate('a').withAttr({ href: '#', class:"navbar-brand" }));
    I.click(locate('a').withAttr({ href: '#posts', class:"nav-link" }));
    I.wait(DEFAULT_WAITING);
    I.see('What book(s) make you cry?');
    I.see('Post migrated');

});

Scenario('Verify Migrate All Functionality', ({ I }) => {
    I.amOnPage('data-migration/#posts');
    I.amOnPage('data-migration/#requests');
    I.amOnPage('data-migration/#posts');
    I.wait(DEFAULT_LONG_WAITING);
    I.scrollPageToBottom();
    I.wait(DEFAULT_LONG_WAITING);
    I.scrollPageToBottom();
    I.wait(DEFAULT_LONG_WAITING);
    I.see('All posts loaded');

    I.click('Select All');
    I.click('Request Selected (2)');
    I.see('Migrate content from 2 posts?');
    I.click('OK');

    session('Admin user', () => {
        I.amOnPage('/');
        I.fillField('Email Address', ADMIN_USERNAME);
        I.fillField('Password', ADMIN_PASS);
        I.click('Log In');
        I.amOnPage('data-migration');
        I.amOnPage('data-migration/#requests');
        I.see('Another post for system testing');
        I.see('Hi a post for system testing');
      });

});

Scenario('Verify Group selection Functionality', async ({ I }) => {

    userData = {
        username: ADMIN_USERNAME,
        password: ADMIN_PASS
    }
    var res = await I.sendPostRequest('wp-json/jwt-auth/v1/token', userData);
    const authToken = res.data.data.token;
    header = {
        Authorization: "Bearer " + authToken
    }
    var res = await I.sendGetRequest('wp-json/custom-api/v1/fbposts/' + TARGET_POST_ID2, header);
    var postID = res.data.ID;

    I.sendDeleteRequest('wp-json/wp/v2/fbposts/' + postID, header);

    session('Admin user',  () => {
        I.amOnPage('/');
        I.fillField('Email Address', ADMIN_USERNAME);
        I.fillField('Password', ADMIN_PASS);
        I.click('Log In');
        I.amOnPage('data-migration');
        I.amOnPage('data-migration/#requests');
        I.see('Hi a post for system testing');
        I.selectOption('Choose a community', 'Quokka (private)');
        I.click('#migrate_' + TARGET_POST_ID3);
        I.click('OK');
      });
});
