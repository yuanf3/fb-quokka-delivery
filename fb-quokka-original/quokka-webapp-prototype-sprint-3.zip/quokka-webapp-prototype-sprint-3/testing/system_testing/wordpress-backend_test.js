Feature('wordpress-backend');

/*
    The Aim of this testing is to verify if the posts, migrated from previous testing (Quokka-migration-APP-testing), have been successfully displayed in Quokka netweok

    <------------------------------------------------------------------------------------------------------------------------------------------>
    Two user invoved in this testing
    - Bob: 
        The user form previous testing collection and he is also a member of Quokka group. His purpose of the testing is to verify if the posts, 
        both public and private group posts, have been displayed in Quokka netweok correctly.
    - Alex
        An anonymous user who is not a member of Quokka group, thus unable to access to the Facebook posts posted to Quokka group by Bob, 
        however he could access to the posts that are posted to public group. His purpose of the testing is to verify if the private group has function correctly.

    <------------------------------------------------------------------------------------------------------------------------------------------>
    Test data Facebook post:

    - 2658160797819865_2703353756633902: "It always seems impossible until it's done"
        For testing the generate migration functionalities

    - 2658160797819865_2703347956634482: "What book(s) make you cry?" with one image
        For testing the image migration functionality

    - 2658160797819865_2688092564826688: "Another post for system testing"
    - 2658160797819865_2687484038220874: "Hi a post for system testing"
        For testing migrate all posts funtionality
*/

// User Quokka network account
const BOB_USERNAME = "Bob"
const BOB_PASS = "Bob"

const ADMIN_USERNAME = "admin"
const ADMIN_PASS = "admin"

const ALEX_USERNAME = "Alex"
const ALEX_PASS = "Alex"

// Test data Facebook post:
const TARGET_POST_ID = "2658160797819865_2703353756633902"
const TARGET_POST_ID1 = "2658160797819865_2703347956634482"
const TARGET_POST_ID2 = "2658160797819865_2688092564826688"
const TARGET_POST_ID3 = "2658160797819865_2687484038220874"

//Default waiting time
const DEFAULT_WAITING = 2
const DEFAULT_LONG_WAITING = 4

// Buddy Boss is not automated AT tools friendly
// instead of checking if the posts have been displayed on Buddy Boss, we check if the posts are stored in the Buddy Boss database
Scenario('Verify Facebook Post has been displayed on Quokka network', async ({ I }) => {

    userData = {
        username: ADMIN_USERNAME,
        password: ADMIN_PASS
    }

    var res = await I.sendPostRequest('wp-json/jwt-auth/v1/token', userData);

    const authToken = res.data.data.token;

    header = {
        Authorization: "Bearer " + authToken
    }

    var res = await I.sendGetRequest('wp-json/buddyboss/v1/activity', header);

    let filtered = res.data.filter(function(value){
        return value.content_stripped == "It always seems impossible until it's done";
    });

    const postID = filtered[0].id;

    I.assert(filtered.length==1, true);
});

// instead of checking if the img has been displayed on Buddy Boss, we check if the img is stored in the Buddy Boss database
Scenario('Verify Image Migration Functionality', async ({ I }) => {

    userData = {
        username: ADMIN_USERNAME,
        password: ADMIN_PASS
    }

    var res = await I.sendPostRequest('wp-json/jwt-auth/v1/token', userData);

    const authToken = res.data.data.token;

    header = {
        Authorization: "Bearer " + authToken
    }

    var res = await I.sendGetRequest('wp-json/buddyboss/v1/activity', header);

    let filtered = res.data.filter(function(value){
        return value.content_stripped == "What book(s) make you cry?";
    });

    const postID = filtered[0].id;

    I.assert(filtered.length==1, true);

    let img = filtered[0].bp_media_ids;

    I.assert(img.length ==1, true);


      
});  

Scenario('Verify Private Group Functionality', ({ I }) => {

    
    session('anonymous user', () => {
        I.amOnPage('/');
        I.fillField('Email Address', ALEX_USERNAME);
        I.fillField('Password', ALEX_PASS);
        I.click('Log In');
        I.see('Welcome to Quokka Network!');
        I.amOnPage('news-feed/');
        I.dontSee("Another post for system testing");
      });
      
});   

Scenario('Data clean for Buddy Boss', async ({ I }) => {

    userData = {
        username: "admin",
        password: "admin"
    }

    var res = await I.sendPostRequest('wp-json/jwt-auth/v1/token', userData);

    const authToken = res.data.data.token;

    header = {
        Authorization: "Bearer " + authToken
    }

    var res = await I.sendGetRequest('wp-json/buddyboss/v1/activity', header);
    var filtered = res.data.filter(function(value){
        return value.content_stripped == "It always seems impossible until it's done";
    });
    var postID = filtered[0].id;
    I.sendDeleteRequest('wp-json/buddyboss/v1/activity/' + postID, header);


    var res = await I.sendGetRequest('wp-json/buddyboss/v1/activity', header);
    var filtered = res.data.filter(function(value){
        return value.content_stripped == "What book(s) make you cry?";
    });
    var postID = filtered[0].id;
    I.sendDeleteRequest('wp-json/buddyboss/v1/activity/' + postID, header);


    var res = await I.sendGetRequest('wp-json/buddyboss/v1/activity', header);
    var filtered = res.data.filter(function(value){
        return value.content_stripped == "Hi a post for system testing";
    });
    var postID = filtered[0].id;
    I.sendDeleteRequest('wp-json/buddyboss/v1/activity/' + postID, header);

});

Scenario('Clean up Testing Data for FBpost type', async ({ I }) => {

    userData = {
        username: "admin",
        password: "admin"
    }

    var res = await I.sendPostRequest('wp-json/jwt-auth/v1/token', userData);

    const authToken = res.data.data.token;

    header = {
        Authorization: "Bearer " + authToken
    }

    var res = await I.sendGetRequest('wp-json/custom-api/v1/fbposts/' + TARGET_POST_ID, header);
    var postID = res.data.ID;
    I.sendDeleteRequest('wp-json/wp/v2/fbposts/' + postID, header);

    var res = await I.sendGetRequest('wp-json/custom-api/v1/fbposts/' + TARGET_POST_ID1, header);
    var postID = res.data.ID;
    I.sendDeleteRequest('wp-json/wp/v2/fbposts/' + postID, header);

    var res = await I.sendGetRequest('wp-json/custom-api/v1/fbposts/' + TARGET_POST_ID3, header);
    var postID = res.data.ID;
    I.sendDeleteRequest('wp-json/wp/v2/fbposts/' + postID, header);
    
});