## Installing the testing program
- navigate to testing/system_testing folder
- npm install

## Setup the testing environment
- ensure Firefox is installed
- ensure there is no pending migration request for admin

## For running the system test
npx codeceptjs run --steps

## For generating the report
npx codeceptjs run --reporter mochawesome
