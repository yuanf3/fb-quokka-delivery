## Setup testing environment
- npm install -g newman
- npm install -g newman-reporter-htmlextra

## Run testing

### Run Auth collection
- newman run Auth.postman_collection.json -g SWEN90014\ FB-Quokka\ backend\ testing.postman_globals.json -r htmlextra

### Run FBposts collection
- newman run FBposts.postman_collection.json -g SWEN90014\ FB-Quokka\ backend\ testing.postman_globals.json -e FBposts\ Environment\ Variables.postman_environment.json -r htmlextra
